import React, { useEffect, useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, Pressable, ScrollView, StyleSheet,
  StatusBar, Alert
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const C = {
  bg: "#FFFDF9", ink: "#212529", muted: "#64748B",
  coral: "#FF6B6B", teal: "#4ECDC4", yellow: "#FFE66D",
  green: "#E2F0CB", peach: "#FFF3CD", white: "#FFFFFF",
  border: "#F1D9D5", success: "#2ECC71"
};

const GAMES = [
  { id:"english", emoji:"🔤", color:"#FFE5E5", en:"English Letters", hi:"अंग्रेज़ी अक्षर", kind:"english" },
  { id:"hindi", emoji:"🪷", color:"#DDF8F4", en:"Hindi Swar & Vyanjan", hi:"हिंदी स्वर-व्यंजन", kind:"hindi" },
  { id:"math", emoji:"➕", color:"#FFF1B8", en:"Maths Quiz", hi:"गणित क्विज़", kind:"math" },
  { id:"identify", emoji:"🍎", color:"#E8F4D7", en:"Animals, Fruits & Colors", hi:"जानवर, फल और रंग", kind:"identify" },
  { id:"gk", emoji:"🌍", color:"#DCEEFF", en:"General Knowledge", hi:"सामान्य ज्ञान", kind:"gk" },
  { id:"memory", emoji:"🧠", color:"#FFE5C7", en:"Memory Match", hi:"याददाश्त गेम", kind:"memory" },
  { id:"science", emoji:"🔬", color:"#E6E7FF", en:"Science Quiz", hi:"विज्ञान क्विज़", kind:"science" },
  { id:"numbers", emoji:"🔢", color:"#FCE1F1", en:"Number Puzzles", hi:"नंबर पहेली", kind:"numbers" },
];

const QUESTIONS = {
 english: [
  {e:"Which letter comes after A?",h:"A के बाद कौन-सा अक्षर आता है?",opts:["B","C","D","E"],ans:0},
  {e:"Which letter starts the word 'Ball'?",h:"'Ball' शब्द किस अक्षर से शुरू होता है?",opts:["D","B","P","M"],ans:1},
  {e:"Which is a vowel?",h:"इनमें से स्वर (vowel) कौन-सा है?",opts:["T","K","A","S"],ans:2},
 ],
 hindi: [
  {e:"Which is a Hindi Swar?",h:"इनमें से हिंदी स्वर कौन-सा है?",opts:["क","अ","म","त"],ans:1},
  {e:"'क' is a…",h:"'क' क्या है?",opts:["स्वर","व्यंजन","अंक","रंग"],ans:1},
  {e:"Which letter comes after अ?",h:"अ के बाद कौन-सा स्वर आता है?",opts:["आ","इ","क","म"],ans:0},
 ],
 math: [
  {e:"What is 2 + 3?",h:"2 + 3 कितना होता है?",opts:["4","5","6","7"],ans:1},
  {e:"What is 10 − 4?",h:"10 − 4 कितना होता है?",opts:["5","6","7","8"],ans:1},
  {e:"You have 3 apples and get 2 more. How many?",h:"3 सेब हैं, 2 और मिले। कुल कितने?",opts:["4","5","6","7"],ans:1},
 ],
 identify: [
  {e:"Which one is a fruit?",h:"इनमें से फल कौन-सा है?",opts:["Carrot","Apple","Chair","Shoe"],ans:1},
  {e:"Which animal says 'meow'?",h:"'म्याऊँ' कौन-सा जानवर करता है?",opts:["Dog","Cow","Cat","Horse"],ans:2},
  {e:"What color is a ripe banana?",h:"पका हुआ केला किस रंग का होता है?",opts:["Blue","Yellow","Purple","Black"],ans:1},
 ],
 gk: [
  {e:"How many days are in a week?",h:"एक सप्ताह में कितने दिन होते हैं?",opts:["5","6","7","8"],ans:2},
  {e:"Which planet do we live on?",h:"हम किस ग्रह पर रहते हैं?",opts:["Mars","Earth","Jupiter","Venus"],ans:1},
  {e:"How many wheels does a bicycle usually have?",h:"साइकिल में आमतौर पर कितने पहिए होते हैं?",opts:["1","2","3","4"],ans:1},
 ],
 memory: [
  {e:"Remember this: 🌞 🐸 🍓. Which fruit did you see?",h:"याद रखें: 🌞 🐸 🍓। आपने कौन-सा फल देखा?",opts:["🍌 Banana","🍓 Strawberry","🍎 Apple","🍇 Grapes"],ans:1},
  {e:"Remember this: 🚗 ⭐ 🐱. Which animal did you see?",h:"याद रखें: 🚗 ⭐ 🐱। आपने कौन-सा जानवर देखा?",opts:["🐶 Dog","🐱 Cat","🐰 Rabbit","🐼 Panda"],ans:1},
  {e:"Remember this: 🐟 🌈 🍋. Which item was yellow?",h:"याद रखें: 🐟 🌈 🍋। कौन-सी चीज़ पीली थी?",opts:["🐟 Fish","🌈 Rainbow","🍋 Lemon","All"],ans:2},
 ],
 science: [
  {e:"What do plants need to grow?",h:"पौधों को बढ़ने के लिए क्या चाहिए?",opts:["Sunlight","Plastic","Toys","Shoes"],ans:0},
  {e:"Which part of the body helps us see?",h:"शरीर का कौन-सा अंग हमें देखने में मदद करता है?",opts:["Ears","Eyes","Hands","Knees"],ans:1},
  {e:"Water turns to ice when it gets…",h:"पानी जमकर बर्फ कब बनता है?",opts:["Very hot","Very cold","Very loud","Very bright"],ans:1},
 ],
 numbers: [
  {e:"What comes next: 2, 4, 6, __?",h:"आगे क्या आएगा: 2, 4, 6, __?",opts:["7","8","9","10"],ans:1},
  {e:"Find the missing number: 5, 10, __, 20",h:"खाली जगह भरें: 5, 10, __, 20",opts:["12","14","15","18"],ans:2},
  {e:"Which number is the biggest?",h:"सबसे बड़ी संख्या कौन-सी है?",opts:["12","21","9","18"],ans:1},
 ]
};

const txt = (lang, en, hi) => lang === "hi" ? hi : en;
const levels = ["5–7", "8–11", "12–15"];

export default function App() {
 const [lang, setLang] = useState("en");
 const [age, setAge] = useState("5–7");
 const [screen, setScreen] = useState("home");
 const [game, setGame] = useState(null);
 const [qIndex, setQIndex] = useState(0);
 const [selected, setSelected] = useState(null);
 const [score, setScore] = useState(0);
 const [stars, setStars] = useState(0);
 const [played, setPlayed] = useState(0);
 const [best, setBest] = useState({});
 const [loading, setLoading] = useState(true);
 const [feedback, setFeedback] = useState("");

 useEffect(() => {
   (async () => {
    try {
      const raw = await AsyncStorage.getItem("hkl_progress_v1");
      if (raw) {
       const data = JSON.parse(raw);
       setStars(Number(data.stars || 0));
       setPlayed(Number(data.played || 0));
       setBest(data.best || {});
      }
    } catch (_) {}
    setLoading(false);
   })();
 }, []);

 useEffect(() => {
   if (!loading) AsyncStorage.setItem("hkl_progress_v1", JSON.stringify({stars, played, best})).catch(() => {});
 }, [stars, played, best, loading]);

 const currentQuestions = game ? QUESTIONS[game.kind] || QUESTIONS.math : [];
 const question = currentQuestions[qIndex];
 const startGame = (g) => {
   setGame(g); setQIndex(0); setSelected(null); setScore(0); setFeedback(""); setScreen("play");
 };
 const answer = (index) => {
   if (selected !== null || !question) return;
   setSelected(index);
   if (index === question.ans) {
     setScore(s => s + 1); setStars(s => s + 1); setFeedback(txt(lang, "Brilliant! +1 star ⭐", "शाबाश! +1 स्टार ⭐"));
   } else {
     setFeedback(txt(lang, "Nice try! Keep learning 💛", "कोई बात नहीं! सीखते रहो 💛"));
   }
 };
 const next = () => {
   if (qIndex < currentQuestions.length - 1) {
     setQIndex(i => i + 1); setSelected(null); setFeedback("");
   } else {
     const finalScore = score;
     setBest(prev => ({...prev, [game.id]: Math.max(prev[game.id] || 0, finalScore)}));
     setPlayed(n => n + 1);
     setScreen("result");
   }
 };
 const resetProgress = () => Alert.alert(
   txt(lang, "Reset progress?", "प्रोग्रेस रीसेट करें?"),
   txt(lang, "Your stars and scores will be cleared.", "आपके स्टार और स्कोर मिट जाएंगे।"),
   [{text:txt(lang,"Cancel","रद्द करें"),style:"cancel"},{text:txt(lang,"Reset","रीसेट"),style:"destructive",onPress:async()=>{setStars(0);setPlayed(0);setBest({});await AsyncStorage.removeItem("hkl_progress_v1");}}]
 );

 const Header = () => (
  <View style={s.header}>
   <View style={s.brandRow}>
    <View style={s.logo}><Text style={{fontSize:25}}>🎈</Text></View>
    <View style={{flex:1}}>
     <Text style={s.brand}>{txt(lang,"Happy Kids","हैप्पी किड्स")}</Text>
     <Text style={s.subtitle}>{txt(lang,"LEARN • PLAY • SHINE","सीखो • खेलो • चमको")}</Text>
    </View>
    <Pressable style={s.langButton} onPress={() => setLang(l => l === "en" ? "hi" : "en")}><Text style={s.langText}>{lang === "en" ? "हिंदी" : "EN"}</Text></Pressable>
   </View>
   <View style={s.statsStrip}>
    <View style={[s.statBox,{backgroundColor:C.yellow}]}><Text style={s.statEmoji}>⭐</Text><Text style={s.statNum}>{stars}</Text><Text style={s.statLabel}>{txt(lang,"Stars","स्टार")}</Text></View>
    <View style={[s.statBox,{backgroundColor:C.green}]}><Text style={s.statEmoji}>🎮</Text><Text style={s.statNum}>{played}</Text><Text style={s.statLabel}>{txt(lang,"Games played","गेम खेले")}</Text></View>
   </View>
  </View>
 );

 const BottomNav = () => (
  <View style={s.bottom}>
   <Pressable onPress={() => setScreen("home")} style={s.navItem}><Text style={s.navIcon}>🏠</Text><Text style={s.navText}>{txt(lang,"Home","होम")}</Text></Pressable>
   <Pressable onPress={() => setScreen("explore")} style={s.navItem}><Text style={s.navIcon}>🧩</Text><Text style={s.navText}>{txt(lang,"Explore","खोजें")}</Text></Pressable>
   <Pressable onPress={() => setScreen("progress")} style={s.navItem}><Text style={s.navIcon}>🏆</Text><Text style={s.navText}>{txt(lang,"Progress","प्रोग्रेस")}</Text></Pressable>
  </View>
 );

 const gameCard = (g) => (
  <Pressable key={g.id} onPress={() => startGame(g)} style={({pressed})=>[s.gameCard,{backgroundColor:g.color,transform:[{scale:pressed?0.97:1}]}]}>
   <Text style={s.gameEmoji}>{g.emoji}</Text>
   <Text style={s.gameTitle}>{txt(lang,g.en,g.hi)}</Text>
   <Text style={s.gameMeta}>⭐ {best[g.id] || 0} {txt(lang,"best","सर्वश्रेष्ठ")}</Text>
   <View style={s.playPill}><Text style={s.playPillText}>{txt(lang,"Play Now →","अभी खेलें →")}</Text></View>
  </Pressable>
 );

 if (loading) return <SafeAreaView style={s.safe}><View style={s.center}><Text style={{fontSize:38}}>⭐</Text><Text style={s.brand}>{txt(lang,"Getting your stars ready…","स्टार तैयार हो रहे हैं…")}</Text></View></SafeAreaView>;

 return (
  <SafeAreaView style={s.safe}>
   <StatusBar barStyle="dark-content" backgroundColor={C.bg}/>
   <Header />
   {screen === "home" && <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
    <View style={s.hero}>
     <View style={{flex:1}}>
      <Text style={s.hello}>{txt(lang,"Hey, little star!","नमस्ते, नन्हे सितारे!")}</Text>
      <Text style={s.heroTitle}>{txt(lang,"Ready to learn something fun?","कुछ मज़ेदार सीखने के लिए तैयार?")}</Text>
      <Text style={s.heroSub}>{txt(lang,"Tiny steps, big discoveries ✨","छोटे कदम, बड़ी खोज ✨")}</Text>
     </View>
     <Text style={s.heroArt}>🦊</Text>
    </View>
    <Text style={s.sectionTitle}>{txt(lang,"Choose your age","अपनी उम्र चुनें")}</Text>
    <View style={s.ageRow}>{levels.map(v=><Pressable key={v} onPress={()=>setAge(v)} style={[s.agePill,age===v&&s.agePillActive]}><Text style={[s.ageText,age===v&&s.ageTextActive]}>{txt(lang,"Ages ","उम्र ")}{v}</Text></Pressable>)}</View>
    <View style={s.sectionRow}><Text style={s.sectionTitle}>{txt(lang,"Pick a learning game","लर्निंग गेम चुनें")}</Text><Text style={s.smallNote}>8 {txt(lang,"games","गेम")}</Text></View>
    <View style={s.grid}>{GAMES.map(gameCard)}</View>
    <View style={s.tip}><Text style={{fontSize:23}}>💡</Text><View style={{flex:1}}><Text style={s.tipTitle}>{txt(lang,"Little tip","छोटी-सी सलाह")}</Text><Text style={s.tipText}>{txt(lang,"Play a little every day. Every correct answer makes you shine!","हर दिन थोड़ा खेलो। हर सही जवाब तुम्हें और चमकाता है!")}</Text></View></View>
   </ScrollView>}

   {screen === "explore" && <ScrollView contentContainerStyle={s.scroll}>
    <Text style={s.pageTitle}>{txt(lang,"Explore all games","सभी गेम देखें")}</Text>
    <Text style={s.pageSub}>{txt(lang,`A fun shelf for ages ${age}`,`उम्र ${age} के लिए मज़ेदार गेम`)}</Text>
    {GAMES.map(g=><Pressable key={g.id} onPress={()=>startGame(g)} style={[s.shelf,{backgroundColor:g.color}]}><Text style={{fontSize:31,marginRight:14}}>{g.emoji}</Text><View style={{flex:1}}><Text style={s.shelfTitle}>{txt(lang,g.en,g.hi)}</Text><Text style={s.shelfSub}>⭐ {best[g.id]||0} {txt(lang,"best score","सर्वश्रेष्ठ स्कोर")}</Text></View><Text style={s.shelfArrow}>›</Text></Pressable>)}
   </ScrollView>}

   {screen === "progress" && <ScrollView contentContainerStyle={s.scroll}>
    <Text style={s.pageTitle}>{txt(lang,"Your progress","आपकी प्रोग्रेस")}</Text>
    <View style={s.progressHero}><Text style={{fontSize:50}}>🏆</Text><Text style={s.progressBig}>{stars} ⭐</Text><Text style={s.progressLabel}>{txt(lang,"Stars collected","स्टार इकट्ठे किए")}</Text><Text style={s.progressSmall}>{txt(lang,`${played} games completed`,`कुल ${played} गेम पूरे किए`)}</Text></View>
    <Text style={s.sectionTitle}>{txt(lang,"Game achievements","गेम उपलब्धियाँ")}</Text>
    {GAMES.map(g=><View key={g.id} style={s.progressRow}><Text style={{fontSize:25}}>{g.emoji}</Text><Text style={s.progressName}>{txt(lang,g.en,g.hi)}</Text><Text style={s.progressScore}>{best[g.id] || 0} ⭐</Text></View>)}
    <Pressable onPress={resetProgress} style={s.resetButton}><Text style={s.resetText}>{txt(lang,"Reset progress","प्रोग्रेस रीसेट करें")}</Text></Pressable>
   </ScrollView>}

   {screen === "play" && game && question && <ScrollView contentContainerStyle={s.playScroll}>
    <View style={s.playTop}><Pressable onPress={()=>setScreen("home")} style={s.backButton}><Text style={s.backText}>‹ {txt(lang,"Home","होम")}</Text></Pressable><Text style={s.scoreBadge}>⭐ {score}</Text></View>
    <View style={s.progressTrack}><View style={[s.progressFill,{width:`${((qIndex+1)/currentQuestions.length)*100}%`}]} /></View>
    <Text style={s.questionCount}>{txt(lang,"QUESTION","सवाल")} {qIndex+1} / {currentQuestions.length}</Text>
    <View style={s.questionCard}><Text style={s.questionEmoji}>{game.emoji}</Text><Text style={s.questionText}>{txt(lang,question.e,question.h)}</Text>{game.kind==="memory"&&<Text style={s.memoryHint}>{txt(lang,"Take a good look at the emojis!","इमोजी को ध्यान से याद करें!")}</Text>}</View>
    <View style={{gap:12,width:"100%"}}>{question.opts.map((opt,i)=>{const correct=selected!==null&&i===question.ans;const wrong=selected===i&&i!==question.ans;return <Pressable key={opt} disabled={selected!==null} onPress={()=>answer(i)} style={[s.answerButton,correct&&s.answerCorrect,wrong&&s.answerWrong]}><View style={s.answerLetter}><Text style={s.answerLetterText}>{["A","B","C","D"][i]}</Text></View><Text style={s.answerText}>{opt}</Text>{correct&&<Text style={{fontSize:21}}>✅</Text>}{wrong&&<Text style={{fontSize:21}}>❌</Text>}</Pressable>})}</View>
    {feedback!==""&&<View style={[s.feedback,selected===question.ans?s.feedbackGood:s.feedbackTry]}><Text style={s.feedbackText}>{feedback}</Text><Pressable style={s.nextButton} onPress={next}><Text style={s.nextText}>{qIndex===currentQuestions.length-1?txt(lang,"See Results 🎉","नतीजे देखें 🎉"):txt(lang,"Next Question →","अगला सवाल →")}</Text></Pressable></View>}
   </ScrollView>}

   {screen === "result" && game && <View style={s.resultWrap}><Text style={{fontSize:76}}>🎉</Text><Text style={s.resultTitle}>{txt(lang,"Amazing work!","बहुत बढ़िया!")}</Text><Text style={s.resultSub}>{txt(lang,"You finished a learning game.","तुमने लर्निंग गेम पूरा किया।")}</Text><View style={s.resultScore}><Text style={s.resultNum}>{score}/{(QUESTIONS[game.kind]||[]).length}</Text><Text style={s.resultLabel}>{txt(lang,"Correct answers","सही जवाब")}</Text><Text style={{fontSize:28,marginTop:8}}>{"⭐".repeat(Math.max(1,score))}</Text></View><Pressable style={s.primaryButton} onPress={()=>startGame(game)}><Text style={s.primaryText}>{txt(lang,"Play Again ↻","फिर से खेलें ↻")}</Text></Pressable><Pressable style={s.secondaryButton} onPress={()=>setScreen("home")}><Text style={s.secondaryText}>{txt(lang,"Back to Home","होम पर जाएँ")}</Text></Pressable></View>}
   {screen !== "play" && screen !== "result" && <BottomNav />}
  </SafeAreaView>
 );
}

const s = StyleSheet.create({
 safe:{flex:1,backgroundColor:C.bg}, header:{paddingHorizontal:18,paddingTop:8,paddingBottom:8,backgroundColor:C.bg},
 brandRow:{flexDirection:"row",alignItems:"center",gap:10},logo:{width:48,height:48,borderRadius:17,backgroundColor:C.yellow,alignItems:"center",justifyContent:"center"},
 brand:{fontSize:23,fontWeight:"900",color:C.ink,letterSpacing:-0.6},subtitle:{fontSize:9,fontWeight:"900",letterSpacing:1.2,color:C.muted,marginTop:1},
 langButton:{paddingHorizontal:14,paddingVertical:10,borderRadius:16,backgroundColor:C.teal,borderBottomWidth:3,borderBottomColor:"#2CAAA2"},langText:{fontWeight:"900",color:C.ink,fontSize:13},
 statsStrip:{flexDirection:"row",gap:10,marginTop:13},statBox:{flex:1,borderRadius:17,paddingVertical:8,paddingHorizontal:12,flexDirection:"row",alignItems:"center",gap:6},statEmoji:{fontSize:17},statNum:{fontSize:18,fontWeight:"900",color:C.ink},statLabel:{fontSize:11,fontWeight:"700",color:C.ink,flexShrink:1},
 scroll:{paddingHorizontal:18,paddingTop:8,paddingBottom:24},hero:{borderRadius:24,backgroundColor:C.coral,padding:19,flexDirection:"row",alignItems:"center",overflow:"hidden",marginBottom:21},hello:{color:"#FFFDF9",fontWeight:"800",fontSize:14},heroTitle:{color:"#FFFDF9",fontSize:21,fontWeight:"900",lineHeight:27,marginTop:5,flexShrink:1},heroSub:{color:"#FFFDF9",fontSize:12,fontWeight:"700",marginTop:7},heroArt:{fontSize:66,marginLeft:5},
 sectionTitle:{fontSize:18,fontWeight:"900",color:C.ink,marginBottom:12},ageRow:{flexDirection:"row",gap:7,marginBottom:22},agePill:{flex:1,paddingVertical:12,borderRadius:15,backgroundColor:C.peach,alignItems:"center",borderWidth:2,borderColor:"transparent"},agePillActive:{backgroundColor:C.yellow,borderColor:C.ink},ageText:{fontSize:11,fontWeight:"800",color:C.ink},ageTextActive:{fontWeight:"900"},
 sectionRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between"},smallNote:{fontSize:12,color:C.muted,fontWeight:"800",marginBottom:12},grid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between",rowGap:12},gameCard:{width:"48.5%",minHeight:171,borderRadius:21,padding:13,borderBottomWidth:4,borderBottomColor:"rgba(33,37,41,0.08)"},gameEmoji:{fontSize:32,marginBottom:7},gameTitle:{fontSize:14,fontWeight:"900",color:C.ink,minHeight:38},gameMeta:{fontSize:10,fontWeight:"700",color:C.muted,marginTop:5},playPill:{alignSelf:"flex-start",marginTop:9,backgroundColor:C.white,borderRadius:11,paddingHorizontal:9,paddingVertical:7},playPillText:{fontSize:10,fontWeight:"900",color:C.ink},
 tip:{flexDirection:"row",gap:12,alignItems:"center",backgroundColor:C.peach,padding:15,borderRadius:20,marginTop:18},tipTitle:{fontWeight:"900",fontSize:14,color:C.ink},tipText:{fontSize:12,lineHeight:18,color:C.ink,marginTop:3},
 bottom:{flexDirection:"row",paddingHorizontal:20,paddingTop:9,paddingBottom:10,borderTopWidth:1,borderColor:C.border,backgroundColor:C.white,justifyContent:"space-around"},navItem:{alignItems:"center",minWidth:64},navIcon:{fontSize:21},navText:{fontSize:10,fontWeight:"800",color:C.ink,marginTop:2},
 pageTitle:{fontSize:25,fontWeight:"900",color:C.ink,marginTop:6},pageSub:{fontSize:13,color:C.muted,marginTop:4,marginBottom:18,fontWeight:"600"},shelf:{flexDirection:"row",alignItems:"center",padding:15,borderRadius:19,marginBottom:11},shelfTitle:{fontSize:15,fontWeight:"900",color:C.ink},shelfSub:{fontSize:11,color:C.muted,fontWeight:"700",marginTop:4},shelfArrow:{fontSize:30,fontWeight:"700",color:C.ink,marginLeft:8},
 progressHero:{backgroundColor:C.yellow,borderRadius:24,alignItems:"center",padding:24,marginTop:17,marginBottom:23},progressBig:{fontSize:36,fontWeight:"900",color:C.ink,marginTop:3},progressLabel:{fontSize:14,fontWeight:"900",color:C.ink},progressSmall:{fontSize:12,fontWeight:"700",color:C.ink,marginTop:7},progressRow:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:12,borderBottomWidth:1,borderColor:C.border},progressName:{flex:1,fontSize:13,fontWeight:"800",color:C.ink},progressScore:{fontSize:13,fontWeight:"900",color:C.ink},resetButton:{marginTop:22,alignItems:"center",padding:14,borderRadius:15,borderWidth:1,borderColor:C.coral},resetText:{color:C.coral,fontWeight:"900"},
 playScroll:{paddingHorizontal:18,paddingTop:8,paddingBottom:30,alignItems:"center"},playTop:{width:"100%",flexDirection:"row",justifyContent:"space-between",alignItems:"center"},backButton:{paddingVertical:10,paddingHorizontal:13,backgroundColor:C.peach,borderRadius:13},backText:{fontWeight:"900",color:C.ink},scoreBadge:{backgroundColor:C.yellow,paddingHorizontal:15,paddingVertical:9,borderRadius:14,fontWeight:"900",color:C.ink},progressTrack:{width:"100%",height:8,backgroundColor:"#F1E5DF",borderRadius:9,marginTop:16,overflow:"hidden"},progressFill:{height:8,backgroundColor:C.teal,borderRadius:9},questionCount:{alignSelf:"flex-start",fontSize:11,fontWeight:"900",letterSpacing:1,color:C.muted,marginTop:20},questionCard:{width:"100%",backgroundColor:C.white,borderWidth:1,borderColor:C.border,borderRadius:25,padding:23,alignItems:"center",marginTop:10,marginBottom:20},questionEmoji:{fontSize:43,marginBottom:12},questionText:{fontSize:21,lineHeight:29,fontWeight:"900",color:C.ink,textAlign:"center"},memoryHint:{fontSize:12,fontWeight:"700",color:C.muted,marginTop:10,textAlign:"center"},answerButton:{width:"100%",minHeight:58,backgroundColor:C.white,borderWidth:2,borderColor:C.border,borderRadius:17,paddingHorizontal:12,flexDirection:"row",alignItems:"center",gap:12},answerCorrect:{backgroundColor:"#E0F8E8",borderColor:C.success},answerWrong:{backgroundColor:"#FFE4E1",borderColor:C.coral},answerLetter:{width:32,height:32,borderRadius:11,backgroundColor:C.peach,alignItems:"center",justifyContent:"center"},answerLetterText:{fontSize:13,fontWeight:"900",color:C.ink},answerText:{fontSize:14,fontWeight:"800",color:C.ink,flex:1},feedback:{width:"100%",padding:15,borderRadius:18,marginTop:18,alignItems:"center"},feedbackGood:{backgroundColor:"#E0F8E8"},feedbackTry:{backgroundColor:C.peach},feedbackText:{fontSize:15,fontWeight:"900",color:C.ink,textAlign:"center"},nextButton:{marginTop:12,backgroundColor:C.coral,borderRadius:15,paddingVertical:13,paddingHorizontal:20,width:"100%",alignItems:"center"},nextText:{fontSize:14,fontWeight:"900",color:C.white},
 center:{flex:1,alignItems:"center",justifyContent:"center",gap:12},resultWrap:{flex:1,padding:25,alignItems:"center",justifyContent:"center"},resultTitle:{fontSize:30,fontWeight:"900",color:C.ink,marginTop:10},resultSub:{fontSize:14,color:C.muted,fontWeight:"700",marginTop:6,textAlign:"center"},resultScore:{backgroundColor:C.yellow,borderRadius:24,padding:25,alignItems:"center",width:"100%",marginVertical:22},resultNum:{fontSize:42,fontWeight:"900",color:C.ink},resultLabel:{fontSize:13,fontWeight:"800",color:C.ink},primaryButton:{width:"100%",backgroundColor:C.coral,padding:16,borderRadius:17,alignItems:"center",marginTop:4},primaryText:{color:C.white,fontSize:15,fontWeight:"900"},secondaryButton:{width:"100%",padding:15,borderRadius:17,alignItems:"center",marginTop:8,borderWidth:2,borderColor:C.border},secondaryText:{fontSize:14,fontWeight:"900",color:C.ink}
});
